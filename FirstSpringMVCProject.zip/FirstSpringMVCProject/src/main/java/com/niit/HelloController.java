package com.niit;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
@Controller 
public class HelloController {
	@RequestMapping("/welcome") 
	public String helloWorld() {
		 
		return "welcome.jsp";
		
}
	@RequestMapping("/test")
	public String helloWorld1() {
		 
		return "test.jsp";
	
}
}

	
